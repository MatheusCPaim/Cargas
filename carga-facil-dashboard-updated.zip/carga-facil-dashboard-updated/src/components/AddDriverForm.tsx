import { useState, useCallback } from "react";
import { UserPlus, X } from "lucide-react";
import { Driver } from "@/data/drivers";

interface AddDriverFormProps {
  onAdd: (driver: Omit<Driver, 'id' | 'viagens'>) => void;
}

const AddDriverForm = ({ onAdd }: AddDriverFormProps) => {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [transportadora, setTransportadora] = useState('');
  const [capacidade, setCapacidade] = useState('');
  const [tipo, setTipo] = useState<'fixo' | 'esporadico'>('fixo');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !capacidade) return;
    onAdd({ name, transportadora, capacidade: Number(capacidade), tipo });
    setName('');
    setTransportadora('');
    setCapacidade('');
    setOpen(false);
  };

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-primary text-primary-foreground font-semibold text-sm hover:opacity-90 transition-opacity"
      >
        <UserPlus size={16} />
        Adicionar Motorista
      </button>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="bg-card border border-border rounded-xl p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Novo Motorista</h3>
        <button type="button" onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground">
          <X size={18} />
        </button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        <input
          value={name}
          onChange={e => setName(e.target.value)}
          placeholder="Nome"
          required
          className="h-10 rounded-lg border border-border bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
        />
        <input
          value={transportadora}
          onChange={e => setTransportadora(e.target.value)}
          placeholder="Transportadora"
          className="h-10 rounded-lg border border-border bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
        />
        <input
          type="number"
          value={capacidade}
          onChange={e => setCapacidade(e.target.value)}
          placeholder="Capacidade (fardos)"
          required
          className="h-10 rounded-lg border border-border bg-background px-3 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-primary/40"
        />
        <select
          value={tipo}
          onChange={e => setTipo(e.target.value as 'fixo' | 'esporadico')}
          className="h-10 rounded-lg border border-border bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
        >
          <option value="fixo">Fixo</option>
          <option value="esporadico">Esporádico</option>
        </select>
        <button
          type="submit"
          className="h-10 rounded-lg bg-accent text-accent-foreground font-semibold text-sm hover:opacity-90 transition-opacity"
        >
          Adicionar
        </button>
      </div>
    </form>
  );
};

export default AddDriverForm;

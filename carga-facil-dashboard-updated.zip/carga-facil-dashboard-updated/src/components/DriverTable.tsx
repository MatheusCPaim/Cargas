import { useState } from "react";
import { Driver } from "@/data/drivers";
import { Check, Pencil, Trash2, Save, X } from "lucide-react";

interface DriverTableProps {
  drivers: Driver[];
  onToggleViagem: (driverId: string, viagemIndex: number) => void;
  onDeleteDriver: (driverId: string) => void;
  onEditDriver: (driver: Driver) => void;
}

const DriverTable = ({ drivers, onToggleViagem, onDeleteDriver, onEditDriver }: DriverTableProps) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editData, setEditData] = useState<Partial<Driver>>({});

  const fixos = drivers.filter(d => d.tipo === 'fixo');
  const esporadicos = drivers.filter(d => d.tipo === 'esporadico');

  const getNumViagens = (d: Driver) => d.viagens.filter(v => v !== null).length;
  const getTotalCarregado = (d: Driver) => getNumViagens(d) * d.capacidade;
  const getStatus = (d: Driver) => {
    const n = getNumViagens(d);
    if (n === 0) return 'aguardando';
    return `${n} viagem${n > 1 ? 's' : ''}`;
  };

  const subtotalFixos = fixos.reduce((sum, d) => sum + getTotalCarregado(d), 0);
  const subtotalEsporadicos = esporadicos.reduce((sum, d) => sum + getTotalCarregado(d), 0);

  const startEdit = (d: Driver) => {
    setEditingId(d.id);
    setEditData({ name: d.name, transportadora: d.transportadora, capacidade: d.capacidade, tipo: d.tipo });
  };

  const saveEdit = (d: Driver) => {
    onEditDriver({ ...d, ...editData } as Driver);
    setEditingId(null);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditData({});
  };

  const renderRow = (d: Driver) => {
    const numViagens = getNumViagens(d);
    const total = getTotalCarregado(d);
    const status = getStatus(d);
    const isEditing = editingId === d.id;

    return (
      <tr key={d.id} className="border-b border-border hover:bg-muted/40 transition-colors">
        <td className="px-3 py-2.5 text-sm">
          {isEditing ? (
            <input value={editData.name || ''} onChange={e => setEditData(p => ({ ...p, name: e.target.value }))}
              className="h-8 w-full rounded border border-border bg-background px-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary/40" />
          ) : <span className="font-medium">{d.name}</span>}
        </td>
        <td className="px-3 py-2.5 text-sm text-muted-foreground">
          {isEditing ? (
            <input value={editData.transportadora || ''} onChange={e => setEditData(p => ({ ...p, transportadora: e.target.value }))}
              className="h-8 w-full rounded border border-border bg-background px-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary/40" />
          ) : (d.transportadora || '—')}
        </td>
        <td className="px-3 py-2.5 text-sm font-mono text-right">
          {isEditing ? (
            <input type="number" value={editData.capacidade || ''} onChange={e => setEditData(p => ({ ...p, capacidade: Number(e.target.value) }))}
              className="h-8 w-20 rounded border border-border bg-background px-2 text-sm font-mono text-right focus:outline-none focus:ring-1 focus:ring-primary/40" />
          ) : d.capacidade.toLocaleString('pt-BR')}
        </td>
        <td className="px-3 py-2.5 text-sm text-center">
          {isEditing ? (
            <select value={editData.tipo} onChange={e => setEditData(p => ({ ...p, tipo: e.target.value as 'fixo' | 'esporadico' }))}
              className="h-8 rounded border border-border bg-background px-2 text-xs focus:outline-none focus:ring-1 focus:ring-primary/40">
              <option value="fixo">Fixo</option>
              <option value="esporadico">Esporádico</option>
            </select>
          ) : (
            <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${d.tipo === 'fixo' ? 'bg-primary/10 text-primary' : 'bg-warning/10 text-warning'}`}>
              {d.tipo === 'fixo' ? 'Fixo' : 'Esporádico'}
            </span>
          )}
        </td>

        {/* Viagem columns — show date when confirmed */}
        {[0, 1, 2].map(i => (
          <td key={i} className="px-3 py-2.5 text-center">
            <div className="flex flex-col items-center gap-0.5">
              <button
                onClick={() => onToggleViagem(d.id, i)}
                title={d.viagens[i] ? `Confirmado em ${d.viagens[i]}` : 'Clique para confirmar'}
                className={`w-8 h-8 rounded-lg border-2 flex items-center justify-center transition-all ${
                  d.viagens[i]
                    ? 'bg-accent border-accent text-accent-foreground shadow-sm'
                    : 'border-border hover:border-primary/40 text-transparent'
                }`}
              >
                <Check size={16} />
              </button>
              {d.viagens[i] && (
                <span className="text-[10px] font-mono text-accent leading-none">{d.viagens[i]}</span>
              )}
            </div>
          </td>
        ))}

        <td className="px-3 py-2.5 text-center font-mono font-semibold text-sm">{numViagens}</td>
        <td className="px-3 py-2.5 text-right font-mono font-semibold text-sm">{total.toLocaleString('pt-BR')}</td>
        <td className="px-3 py-2.5 text-center">
          <span className={`inline-block px-2.5 py-1 rounded-full text-xs font-semibold ${
            numViagens === 0
              ? 'bg-muted text-muted-foreground'
              : numViagens >= 2
                ? 'bg-accent/15 text-accent'
                : 'bg-primary/10 text-primary'
          }`}>
            {status}
          </span>
        </td>
        <td className="px-3 py-2.5 text-center">
          <div className="flex items-center justify-center gap-1">
            {isEditing ? (
              <>
                <button onClick={() => saveEdit(d)} className="p-1.5 rounded-md hover:bg-accent/10 text-accent transition-colors" title="Salvar">
                  <Save size={14} />
                </button>
                <button onClick={cancelEdit} className="p-1.5 rounded-md hover:bg-muted text-muted-foreground transition-colors" title="Cancelar">
                  <X size={14} />
                </button>
              </>
            ) : (
              <>
                <button onClick={() => startEdit(d)} className="p-1.5 rounded-md hover:bg-primary/10 text-muted-foreground hover:text-primary transition-colors" title="Editar">
                  <Pencil size={14} />
                </button>
                <button onClick={() => onDeleteDriver(d.id)} className="p-1.5 rounded-md hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors" title="Excluir">
                  <Trash2 size={14} />
                </button>
              </>
            )}
          </div>
        </td>
      </tr>
    );
  };

  return (
    <div className="bg-card rounded-xl border border-border overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-muted/60">
              <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Motorista</th>
              <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Transportadora</th>
              <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-right">Capacidade</th>
              <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Tipo</th>
              <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Viagem 1</th>
              <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Viagem 2</th>
              <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Viagem 3</th>
              <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Nº Viagens</th>
              <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-right">Total</th>
              <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Status</th>
              <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Ações</th>
            </tr>
          </thead>
          <tbody>
            {/* Fixos */}
            <tr>
              <td colSpan={11} className="px-3 py-2 bg-primary/5 border-b border-border">
                <span className="text-xs font-bold uppercase tracking-widest text-primary">Motoristas Fixos</span>
              </td>
            </tr>
            {fixos.map(renderRow)}
            <tr className="bg-muted/40 border-b border-border">
              <td colSpan={8} className="px-3 py-2 text-sm font-bold text-right">Subtotal Fixos</td>
              <td className="px-3 py-2 text-right font-mono font-bold text-sm">{subtotalFixos.toLocaleString('pt-BR')}</td>
              <td colSpan={2} />
            </tr>

            {/* Esporádicos */}
            <tr>
              <td colSpan={11} className="px-3 py-2 bg-warning/5 border-b border-border">
                <span className="text-xs font-bold uppercase tracking-widest text-warning">Motoristas Esporádicos</span>
              </td>
            </tr>
            {esporadicos.map(renderRow)}
            <tr className="bg-muted/40 border-b border-border">
              <td colSpan={8} className="px-3 py-2 text-sm font-bold text-right">Subtotal Esporádicos</td>
              <td className="px-3 py-2 text-right font-mono font-bold text-sm">{subtotalEsporadicos.toLocaleString('pt-BR')}</td>
              <td colSpan={2} />
            </tr>

            {/* Total */}
            <tr className="bg-primary/10">
              <td colSpan={8} className="px-3 py-3 text-sm font-bold text-right uppercase">Total Geral</td>
              <td className="px-3 py-3 text-right font-mono font-bold text-lg text-primary">{(subtotalFixos + subtotalEsporadicos).toLocaleString('pt-BR')}</td>
              <td colSpan={2} />
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DriverTable;

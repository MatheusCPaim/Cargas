import { RegionState } from "@/components/RegionTab";
import { Driver } from "@/data/drivers";
import { BarChart3, DollarSign, Package, Truck } from "lucide-react";

interface PosicaoAnaliticaProps {
  regions: RegionState[];
}

const PosicaoAnalitica = ({ regions }: PosicaoAnaliticaProps) => {
  // ── Aggregated totals across ALL regions ──────────────────────────────────
  const totalFardosDisponiveis = regions.reduce((s, r) => s + r.fardosDisponiveis, 0);

  const totalCarregado = regions.reduce((s, r) =>
    s + r.drivers.reduce((ds, d) => ds + d.viagens.filter(v => v !== null).length * d.capacidade, 0),
  0);

  const totalFaturamento = regions.reduce((s, r) => {
    const carregado = r.drivers.reduce((ds, d) =>
      ds + d.viagens.filter(v => v !== null).length * d.capacidade, 0
    );
    return s + carregado * r.valorFrete;
  }, 0);

  const totalFretes = regions.reduce((s, r) =>
    s + r.drivers.reduce((ds, d) => ds + d.viagens.filter(v => v !== null).length, 0),
  0);

  const saldoRestante = totalFardosDisponiveis - totalCarregado;
  const percentCarregado = totalFardosDisponiveis > 0
    ? (totalCarregado / totalFardosDisponiveis) * 100
    : 0;

  // ── All drivers across regions (with region name) ─────────────────────────
  type DriverWithRegion = Driver & { regionName: string; valorFrete: number };

  const allDrivers: DriverWithRegion[] = regions.flatMap(r =>
    r.drivers.map(d => ({ ...d, regionName: r.name, valorFrete: r.valorFrete }))
  );

  const fixos = allDrivers.filter(d => d.tipo === "fixo");
  const esporadicos = allDrivers.filter(d => d.tipo === "esporadico");

  const getNumViagens = (d: Driver) => d.viagens.filter(v => v !== null).length;
  const getTotalCarregado = (d: Driver) => getNumViagens(d) * d.capacidade;
  const getFaturamento = (d: DriverWithRegion) => getTotalCarregado(d) * d.valorFrete;

  const subtotalFixosCarregado = fixos.reduce((s, d) => s + getTotalCarregado(d), 0);
  const subtotalEsporadicosCarregado = esporadicos.reduce((s, d) => s + getTotalCarregado(d), 0);
  const subtotalFixosFaturamento = fixos.reduce((s, d) => s + getFaturamento(d), 0);
  const subtotalEsporFaturamento = esporadicos.reduce((s, d) => s + getFaturamento(d), 0);

  const renderRow = (d: DriverWithRegion) => {
    const numViagens = getNumViagens(d);
    const total = getTotalCarregado(d);
    const faturamento = getFaturamento(d);

    return (
      <tr key={`${d.regionName}-${d.id}`} className="border-b border-border hover:bg-muted/40 transition-colors">
        <td className="px-3 py-2.5 text-sm font-medium">{d.name}</td>
        <td className="px-3 py-2.5 text-sm text-muted-foreground">{d.transportadora || "—"}</td>
        <td className="px-3 py-2.5 text-xs">
          <span className="inline-block px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium">
            {d.regionName}
          </span>
        </td>
        <td className="px-3 py-2.5 text-sm font-mono text-right">{d.capacidade.toLocaleString("pt-BR")}</td>

        {/* Viagem columns – show date if confirmed */}
        {[0, 1, 2].map(i => (
          <td key={i} className="px-3 py-2.5 text-center">
            {d.viagens[i] ? (
              <span className="inline-block px-2 py-0.5 rounded-md bg-accent/15 text-accent text-xs font-mono font-semibold whitespace-nowrap">
                {d.viagens[i]}
              </span>
            ) : (
              <span className="text-muted-foreground/40 text-xs">—</span>
            )}
          </td>
        ))}

        <td className="px-3 py-2.5 text-center font-mono font-semibold text-sm">{numViagens}</td>
        <td className="px-3 py-2.5 text-right font-mono font-semibold text-sm">{total.toLocaleString("pt-BR")}</td>
        <td className="px-3 py-2.5 text-right font-mono text-sm text-warning font-semibold">
          {faturamento > 0
            ? `R$ ${faturamento.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`
            : "—"}
        </td>
      </tr>
    );
  };

  return (
    <div className="space-y-6">
      {/* ── KPI Cards ─────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          icon={<Package size={20} />}
          label="Fardos Disponíveis"
          value={totalFardosDisponiveis.toLocaleString("pt-BR")}
          color="primary"
        />
        <KpiCard
          icon={<Truck size={20} />}
          label="Total Carregado"
          value={totalCarregado.toLocaleString("pt-BR")}
          sub={`${percentCarregado.toFixed(1)}% do total`}
          color="accent"
        />
        <KpiCard
          icon={<BarChart3 size={20} />}
          label="Volume de Fretes"
          value={totalFretes.toLocaleString("pt-BR")}
          sub={`viagens confirmadas`}
          color="muted"
        />
        <KpiCard
          icon={<DollarSign size={20} />}
          label="Faturamento Total"
          value={`R$ ${totalFaturamento.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
          color="warning"
        />
      </div>

      {/* ── Progress bar ──────────────────────────────────────────────────── */}
      <div className="bg-card rounded-lg p-4 border border-border">
        <div className="flex justify-between text-xs text-muted-foreground mb-1.5">
          <span>Progresso Global de Carregamento</span>
          <span className="font-mono font-semibold">{percentCarregado.toFixed(1)}%</span>
        </div>
        <div className="h-3 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-accent rounded-full transition-all duration-700 ease-out"
            style={{ width: `${Math.min(percentCarregado, 100)}%` }}
          />
        </div>
        <div className="flex justify-between text-xs text-muted-foreground mt-1.5">
          <span>Saldo restante: <span className={`font-semibold font-mono ${saldoRestante < 0 ? "text-destructive" : ""}`}>{saldoRestante.toLocaleString("pt-BR")}</span></span>
          <span>{regions.length} região{regions.length !== 1 ? "ões" : ""} consolidada{regions.length !== 1 ? "s" : ""}</span>
        </div>
      </div>

      {/* ── Per-region summary ────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
        {regions.map(r => {
          const rCarregado = r.drivers.reduce(
            (s, d) => s + d.viagens.filter(v => v !== null).length * d.capacidade, 0
          );
          const rFaturamento = rCarregado * r.valorFrete;
          const rFretes = r.drivers.reduce((s, d) => s + d.viagens.filter(v => v !== null).length, 0);
          const rPct = r.fardosDisponiveis > 0 ? (rCarregado / r.fardosDisponiveis) * 100 : 0;

          return (
            <div key={r.id} className="bg-card border border-border rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-sm">{r.name}</span>
                <span className="text-xs text-muted-foreground font-mono">{rPct.toFixed(1)}%</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(rPct, 100)}%` }}
                />
              </div>
              <div className="grid grid-cols-3 gap-2 pt-1">
                <div>
                  <p className="text-xs text-muted-foreground">Carregado</p>
                  <p className="font-mono font-semibold text-sm">{rCarregado.toLocaleString("pt-BR")}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Fretes</p>
                  <p className="font-mono font-semibold text-sm">{rFretes}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Faturamento</p>
                  <p className="font-mono font-semibold text-sm text-warning">
                    {rFaturamento > 0
                      ? `R$ ${rFaturamento.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`
                      : "—"}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ── Consolidated driver table ─────────────────────────────────────── */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="px-4 py-3 border-b border-border bg-muted/40 flex items-center gap-2">
          <BarChart3 size={16} className="text-primary" />
          <span className="font-semibold text-sm">Posição Analítica — Todos os Motoristas</span>
          <span className="ml-auto text-xs text-muted-foreground">{allDrivers.length} motoristas</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-muted/60">
                <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Motorista</th>
                <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Transportadora</th>
                <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Região</th>
                <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-right">Capacidade</th>
                <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Viagem 1</th>
                <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Viagem 2</th>
                <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Viagem 3</th>
                <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Nº Viagens</th>
                <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-right">Total Fardos</th>
                <th className="px-3 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-right">Faturamento</th>
              </tr>
            </thead>
            <tbody>
              {/* Fixos */}
              <tr>
                <td colSpan={10} className="px-3 py-2 bg-primary/5 border-b border-border">
                  <span className="text-xs font-bold uppercase tracking-widest text-primary">Motoristas Fixos</span>
                </td>
              </tr>
              {fixos.map(renderRow)}
              <tr className="bg-muted/40 border-b border-border">
                <td colSpan={8} className="px-3 py-2 text-sm font-bold text-right">Subtotal Fixos</td>
                <td className="px-3 py-2 text-right font-mono font-bold text-sm">{subtotalFixosCarregado.toLocaleString("pt-BR")}</td>
                <td className="px-3 py-2 text-right font-mono font-bold text-sm text-warning">
                  R$ {subtotalFixosFaturamento.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </td>
              </tr>

              {/* Esporádicos */}
              <tr>
                <td colSpan={10} className="px-3 py-2 bg-warning/5 border-b border-border">
                  <span className="text-xs font-bold uppercase tracking-widest text-warning">Motoristas Esporádicos</span>
                </td>
              </tr>
              {esporadicos.map(renderRow)}
              <tr className="bg-muted/40 border-b border-border">
                <td colSpan={8} className="px-3 py-2 text-sm font-bold text-right">Subtotal Esporádicos</td>
                <td className="px-3 py-2 text-right font-mono font-bold text-sm">{subtotalEsporadicosCarregado.toLocaleString("pt-BR")}</td>
                <td className="px-3 py-2 text-right font-mono font-bold text-sm text-warning">
                  R$ {subtotalEsporFaturamento.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </td>
              </tr>

              {/* Total Geral */}
              <tr className="bg-primary/10">
                <td colSpan={8} className="px-3 py-3 text-sm font-bold text-right uppercase">Total Geral</td>
                <td className="px-3 py-3 text-right font-mono font-bold text-lg text-primary">
                  {totalCarregado.toLocaleString("pt-BR")}
                </td>
                <td className="px-3 py-3 text-right font-mono font-bold text-lg text-warning">
                  R$ {totalFaturamento.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const KpiCard = ({
  icon,
  label,
  value,
  sub,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub?: string;
  color: string;
}) => (
  <div className="bg-card rounded-xl border border-border p-4 flex items-start gap-3">
    <div className={`p-2 rounded-lg ${
      color === "primary"   ? "bg-primary/10 text-primary" :
      color === "accent"    ? "bg-accent/10 text-accent" :
      color === "warning"   ? "bg-warning/10 text-warning" :
      color === "destructive" ? "bg-destructive/10 text-destructive" :
      "bg-muted text-muted-foreground"
    }`}>
      {icon}
    </div>
    <div className="min-w-0">
      <p className="text-xs text-muted-foreground uppercase tracking-wider">{label}</p>
      <p className="text-xl font-bold font-mono truncate">{value}</p>
      {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
    </div>
  </div>
);

export default PosicaoAnalitica;

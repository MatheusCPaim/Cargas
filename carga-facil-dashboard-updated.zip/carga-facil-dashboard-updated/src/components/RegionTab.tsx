import { useState, useCallback } from "react";
import { Driver } from "@/data/drivers";
import StatsCards from "@/components/StatsCards";
import DriverTable from "@/components/DriverTable";
import AddDriverForm from "@/components/AddDriverForm";

export interface RegionState {
  id: string;
  name: string;
  fardosDisponiveis: number;
  valorFrete: number;
  drivers: Driver[];
  nextId: number;
}

const RegionTab = ({
  region,
  onUpdate,
}: {
  region: RegionState;
  onUpdate: (r: RegionState) => void;
}) => {
  const handleToggleViagem = useCallback((driverId: string, viagemIndex: number) => {
    onUpdate({
      ...region,
      drivers: region.drivers.map(d => {
        if (d.id !== driverId) return d;
        const newViagens = [...d.viagens];
        newViagens[viagemIndex] = newViagens[viagemIndex] ? null : new Date().toLocaleDateString('pt-BR');
        return { ...d, viagens: newViagens };
      }),
    });
  }, [region, onUpdate]);

  const handleReset = useCallback(() => {
    onUpdate({
      ...region,
      drivers: region.drivers.map(d => ({ ...d, viagens: [null, null, null] })),
    });
  }, [region, onUpdate]);

  const handleAddDriver = useCallback((data: Omit<Driver, 'id' | 'viagens'>) => {
    const newDriver: Driver = {
      ...data,
      id: crypto.randomUUID(),
      viagens: [null, null, null],
    };
    onUpdate({
      ...region,
      drivers: [...region.drivers, newDriver],
      nextId: region.nextId + 1,
    });
  }, [region, onUpdate]);

  const handleDeleteDriver = useCallback((driverId: string) => {
    onUpdate({
      ...region,
      drivers: region.drivers.filter(d => d.id !== driverId),
    });
  }, [region, onUpdate]);

  const handleEditDriver = useCallback((updated: Driver) => {
    onUpdate({
      ...region,
      drivers: region.drivers.map(d => d.id === updated.id ? updated : d),
    });
  }, [region, onUpdate]);

  const totalCarregado = region.drivers.reduce((sum, d) => {
    return sum + d.viagens.filter(v => v !== null).length * d.capacidade;
  }, 0);

  const saldoRestante = region.fardosDisponiveis - totalCarregado;
  const faturamentoTotal = totalCarregado * region.valorFrete;

  return (
    <div className="space-y-6">
      <StatsCards
        fardosDisponiveis={region.fardosDisponiveis}
        totalCarregado={totalCarregado}
        saldoRestante={saldoRestante}
        faturamentoTotal={faturamentoTotal}
        valorFrete={region.valorFrete}
        onFardosChange={v => onUpdate({ ...region, fardosDisponiveis: v })}
        onFreteChange={v => onUpdate({ ...region, valorFrete: v })}
        onReset={handleReset}
      />
      <AddDriverForm onAdd={handleAddDriver} />
      <DriverTable drivers={region.drivers} onToggleViagem={handleToggleViagem} onDeleteDriver={handleDeleteDriver} onEditDriver={handleEditDriver} />
    </div>
  );
};

export default RegionTab;

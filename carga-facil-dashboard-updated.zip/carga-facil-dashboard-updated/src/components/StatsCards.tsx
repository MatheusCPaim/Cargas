import { Package, Truck, DollarSign, RotateCcw } from "lucide-react";

interface StatsCardsProps {
  fardosDisponiveis: number;
  totalCarregado: number;
  saldoRestante: number;
  faturamentoTotal: number;
  valorFrete: number;
  onFardosChange: (val: number) => void;
  onFreteChange: (val: number) => void;
  onReset: () => void;
}

const StatsCards = ({
  fardosDisponiveis,
  totalCarregado,
  saldoRestante,
  faturamentoTotal,
  valorFrete,
  onFardosChange,
  onFreteChange,
  onReset,
}: StatsCardsProps) => {
  const percentCarregado = fardosDisponiveis > 0 ? (totalCarregado / fardosDisponiveis) * 100 : 0;

  return (
    <div className="space-y-4">
      {/* Inputs row */}
      <div className="flex flex-wrap gap-3 items-end">
        <div className="flex-1 min-w-[180px]">
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1 block">
            Fardos Disponíveis
          </label>
          <input
            type="number"
            value={fardosDisponiveis || ''}
            onChange={(e) => onFardosChange(Number(e.target.value))}
            className="w-full h-11 rounded-lg border border-border bg-card px-3 font-mono text-lg font-semibold text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 transition-all"
            placeholder="0"
          />
        </div>
        <div className="flex-1 min-w-[180px]">
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1 block">
            Valor Frete / Fardo (R$)
          </label>
          <input
            type="number"
            step="0.01"
            value={valorFrete || ''}
            onChange={(e) => onFreteChange(Number(e.target.value))}
            className="w-full h-11 rounded-lg border border-border bg-card px-3 font-mono text-lg font-semibold text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 transition-all"
            placeholder="0.00"
          />
        </div>
        <button
          onClick={onReset}
          className="h-11 px-5 rounded-lg bg-destructive text-destructive-foreground font-semibold text-sm flex items-center gap-2 hover:opacity-90 transition-opacity"
        >
          <RotateCcw size={16} />
          Resetar
        </button>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard
          icon={<Package size={20} />}
          label="Fardos Disponíveis"
          value={fardosDisponiveis.toLocaleString('pt-BR')}
          color="primary"
        />
        <StatCard
          icon={<Truck size={20} />}
          label="Total Carregado"
          value={totalCarregado.toLocaleString('pt-BR')}
          sub={`${percentCarregado.toFixed(1)}% do total`}
          color="accent"
        />
        <StatCard
          icon={<Package size={20} />}
          label="Saldo Restante"
          value={saldoRestante.toLocaleString('pt-BR')}
          color={saldoRestante < 0 ? "destructive" : "muted"}
        />
        <StatCard
          icon={<DollarSign size={20} />}
          label="Faturamento Total"
          value={`R$ ${faturamentoTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          color="warning"
        />
      </div>

      {/* Progress bar */}
      <div className="bg-card rounded-lg p-3 border border-border">
        <div className="flex justify-between text-xs text-muted-foreground mb-1.5">
          <span>Progresso de Carregamento</span>
          <span className="font-mono font-semibold">{percentCarregado.toFixed(1)}%</span>
        </div>
        <div className="h-3 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-accent rounded-full transition-all duration-700 ease-out"
            style={{ width: `${Math.min(percentCarregado, 100)}%` }}
          />
        </div>
      </div>
    </div>
  );
};

const StatCard = ({
  icon,
  label,
  value,
  sub,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub?: string;
  color: string;
}) => (
  <div className="bg-card rounded-xl border border-border p-4 flex items-start gap-3">
    <div className={`p-2 rounded-lg ${
      color === 'primary' ? 'bg-primary/10 text-primary' :
      color === 'accent' ? 'bg-accent/10 text-accent' :
      color === 'destructive' ? 'bg-destructive/10 text-destructive' :
      color === 'warning' ? 'bg-warning/10 text-warning' :
      'bg-muted text-muted-foreground'
    }`}>
      {icon}
    </div>
    <div className="min-w-0">
      <p className="text-xs text-muted-foreground uppercase tracking-wider">{label}</p>
      <p className="text-xl font-bold font-mono truncate">{value}</p>
      {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
    </div>
  </div>
);

export default StatsCards;

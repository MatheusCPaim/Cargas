export interface Driver {
  id: string;
  name: string;
  transportadora: string;
  capacidade: number;
  tipo: 'fixo' | 'esporadico';
  viagens: (string | null)[]; // up to 3 trip dates
}

export const defaultDrivers: Driver[] = [
  // Fixos
  { id: '1', name: 'Renato Júlio', transportadora: 'AC Mengue', capacidade: 1050, tipo: 'fixo', viagens: [null, null, null] },
  { id: '2', name: 'Marcos', transportadora: 'AC Mengue', capacidade: 1295, tipo: 'fixo', viagens: [null, null, null] },
  { id: '3', name: 'Jacir', transportadora: 'AC Mengue', capacidade: 1190, tipo: 'fixo', viagens: [null, null, null] },
  { id: '4', name: 'Romulo', transportadora: 'AC Mengue', capacidade: 1610, tipo: 'fixo', viagens: [null, null, null] },
  { id: '5', name: 'Evair', transportadora: 'AC Mengue', capacidade: 1295, tipo: 'fixo', viagens: [null, null, null] },
  { id: '6', name: 'Hilson', transportadora: 'AC Mengue', capacidade: 1295, tipo: 'fixo', viagens: [null, null, null] },
  { id: '7', name: 'Jovane', transportadora: 'AC Mengue', capacidade: 1295, tipo: 'fixo', viagens: [null, null, null] },
  { id: '8', name: 'Ivanio', transportadora: 'AC Mengue', capacidade: 1050, tipo: 'fixo', viagens: [null, null, null] },
  { id: '9', name: 'Nilton', transportadora: 'AC Mengue', capacidade: 1295, tipo: 'fixo', viagens: [null, null, null] },
  { id: '10', name: 'José Roberto', transportadora: 'RV Trans', capacidade: 1295, tipo: 'fixo', viagens: [null, null, null] },
  { id: '11', name: 'Fabiano', transportadora: 'RV Transportes', capacidade: 1190, tipo: 'fixo', viagens: [null, null, null] },
  { id: '12', name: 'Fábio Masschmman', transportadora: 'RV Trans', capacidade: 1225, tipo: 'fixo', viagens: [null, null, null] },
  { id: '13', name: 'Luiz Carlos', transportadora: 'Kal', capacidade: 1295, tipo: 'fixo', viagens: [null, null, null] },
  { id: '14', name: 'Andre Luiz', transportadora: 'Kal', capacidade: 1295, tipo: 'fixo', viagens: [null, null, null] },
  { id: '15', name: 'Enio', transportadora: 'Kal', capacidade: 1190, tipo: 'fixo', viagens: [null, null, null] },
  { id: '16', name: 'Cléber', transportadora: '', capacidade: 1050, tipo: 'fixo', viagens: [null, null, null] },
  { id: '17', name: 'Evandro', transportadora: '', capacidade: 1015, tipo: 'fixo', viagens: [null, null, null] },
  { id: '18', name: 'Vanderlei Vargas', transportadora: '', capacidade: 1295, tipo: 'fixo', viagens: [null, null, null] },
  { id: '19', name: 'Honorino', transportadora: '', capacidade: 1155, tipo: 'fixo', viagens: [null, null, null] },
  { id: '20', name: 'Ismael', transportadora: '', capacidade: 1260, tipo: 'fixo', viagens: [null, null, null] },
  { id: '21', name: 'Ticiano', transportadora: '', capacidade: 1050, tipo: 'fixo', viagens: [null, null, null] },
  { id: '22', name: 'Sérgio Siton', transportadora: '', capacidade: 1295, tipo: 'fixo', viagens: [null, null, null] },
  { id: '23', name: 'Gláuber', transportadora: '', capacidade: 1155, tipo: 'fixo', viagens: [null, null, null] },
  { id: '24', name: 'Ricardo Hendler', transportadora: '', capacidade: 1050, tipo: 'fixo', viagens: [null, null, null] },
  { id: '25', name: 'Luciano', transportadora: '', capacidade: 1050, tipo: 'fixo', viagens: [null, null, null] },
  { id: '26', name: 'Anderson Cucker', transportadora: '', capacidade: 1050, tipo: 'fixo', viagens: [null, null, null] },
  // Esporádicos
  { id: '27', name: 'Marcos Vinicius', transportadora: 'Do Prado', capacidade: 1295, tipo: 'esporadico', viagens: [null, null, null] },
  { id: '28', name: 'Mauricio do Prado', transportadora: 'Do Prado', capacidade: 1295, tipo: 'esporadico', viagens: [null, null, null] },
  { id: '29', name: 'Filipi', transportadora: 'Garcia', capacidade: 1295, tipo: 'esporadico', viagens: [null, null, null] },
  { id: '30', name: 'Alyson', transportadora: 'Garcia', capacidade: 1295, tipo: 'esporadico', viagens: [null, null, null] },
  { id: '31', name: 'Carlos Alexandre', transportadora: 'Garcia', capacidade: 1295, tipo: 'esporadico', viagens: [null, null, null] },
  { id: '32', name: 'Vorni', transportadora: '', capacidade: 1155, tipo: 'esporadico', viagens: [null, null, null] },
  { id: '33', name: 'Gustavo Araujo', transportadora: '', capacidade: 1295, tipo: 'esporadico', viagens: [null, null, null] },
  { id: '34', name: 'Jonathan Felipe', transportadora: '', capacidade: 1260, tipo: 'esporadico', viagens: [null, null, null] },
  { id: '35', name: 'Diego Ferreira', transportadora: '', capacidade: 1295, tipo: 'esporadico', viagens: [null, null, null] },
  { id: '36', name: 'Felipe Leal', transportadora: '', capacidade: 1295, tipo: 'esporadico', viagens: [null, null, null] },
];

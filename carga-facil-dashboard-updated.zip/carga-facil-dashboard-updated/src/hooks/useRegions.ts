import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { RegionState } from "@/components/RegionTab";
import { Driver } from "@/data/drivers";
import { defaultDrivers } from "@/data/drivers";
import { toast } from "sonner";

type DbRegion = {
  id: string;
  name: string;
  fardos_disponiveis: number;
  valor_frete: number;
  sort_order: number;
};

type DbDriver = {
  id: string;
  region_id: string;
  name: string;
  transportadora: string;
  capacidade: number;
  tipo: string;
  viagem1: string | null;
  viagem2: string | null;
  viagem3: string | null;
};

const dbDriverToDriver = (d: DbDriver): Driver => ({
  id: d.id,
  name: d.name,
  transportadora: d.transportadora,
  capacidade: d.capacidade,
  tipo: d.tipo as 'fixo' | 'esporadico',
  viagens: [d.viagem1, d.viagem2, d.viagem3],
});

export const useRegions = () => {
  const [regions, setRegions] = useState<RegionState[]>([]);
  const [loading, setLoading] = useState(true);

  // Load all data from Supabase
  const loadData = useCallback(async () => {
    const { data: dbRegions, error: regErr } = await supabase
      .from('regions')
      .select('*')
      .order('sort_order');

    if (regErr) {
      console.error('Error loading regions:', regErr);
      toast.error('Erro ao carregar regiões');
      setLoading(false);
      return;
    }

    if (!dbRegions || dbRegions.length === 0) {
      // Seed default data
      await seedDefaultData();
      return;
    }

    const { data: dbDrivers, error: drvErr } = await supabase
      .from('drivers')
      .select('*');

    if (drvErr) {
      console.error('Error loading drivers:', drvErr);
      toast.error('Erro ao carregar motoristas');
      setLoading(false);
      return;
    }

    const regionStates: RegionState[] = dbRegions.map((r, idx) => {
      const regionDrivers = (dbDrivers || [])
        .filter(d => d.region_id === r.id)
        .map(dbDriverToDriver);
      return {
        id: r.id,
        name: r.name,
        fardosDisponiveis: r.fardos_disponiveis,
        valorFrete: Number(r.valor_frete),
        drivers: regionDrivers,
        nextId: 1, // not used with UUID
      };
    });

    setRegions(regionStates);
    setLoading(false);
  }, []);

  const seedDefaultData = async () => {
    // Insert default region
    const { data: newRegion, error: err1 } = await supabase
      .from('regions')
      .insert({ name: 'Engenho AM', fardos_disponiveis: 37975, valor_frete: 0, sort_order: 0 })
      .select()
      .single();

    if (err1 || !newRegion) {
      console.error('Error seeding region:', err1);
      setLoading(false);
      return;
    }

    // Insert default drivers
    const driverInserts = defaultDrivers.map(d => ({
      region_id: newRegion.id,
      name: d.name,
      transportadora: d.transportadora,
      capacidade: d.capacidade,
      tipo: d.tipo,
    }));

    await supabase.from('drivers').insert(driverInserts);
    await loadData();
  };

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Update a region's metadata (name, fardos, frete)
  const updateRegion = useCallback(async (updated: RegionState) => {
    // Optimistic update
    setRegions(prev => prev.map(r => r.id === updated.id ? updated : r));

    await supabase
      .from('regions')
      .update({
        name: updated.name,
        fardos_disponiveis: updated.fardosDisponiveis,
        valor_frete: updated.valorFrete,
      })
      .eq('id', updated.id);
  }, []);

  // Sync driver changes
  const updateRegionFull = useCallback(async (updated: RegionState, prev: RegionState) => {
    // Optimistic update
    setRegions(rs => rs.map(r => r.id === updated.id ? updated : r));

    // Update region metadata
    await supabase
      .from('regions')
      .update({
        name: updated.name,
        fardos_disponiveis: updated.fardosDisponiveis,
        valor_frete: updated.valorFrete,
      })
      .eq('id', updated.id);

    // Find added drivers (in updated but not in prev)
    const prevIds = new Set(prev.drivers.map(d => d.id));
    const addedDrivers = updated.drivers.filter(d => !prevIds.has(d.id));
    if (addedDrivers.length > 0) {
      await supabase.from('drivers').insert(
        addedDrivers.map(d => ({
          id: d.id,
          region_id: updated.id,
          name: d.name,
          transportadora: d.transportadora,
          capacidade: d.capacidade,
          tipo: d.tipo,
          viagem1: d.viagens[0],
          viagem2: d.viagens[1],
          viagem3: d.viagens[2],
        }))
      );
    }

    // Find removed drivers
    const updatedIds = new Set(updated.drivers.map(d => d.id));
    const removedDrivers = prev.drivers.filter(d => !updatedIds.has(d.id));
    if (removedDrivers.length > 0) {
      await supabase.from('drivers').delete().in('id', removedDrivers.map(d => d.id));
    }

    // Find modified drivers
    for (const d of updated.drivers) {
      if (prevIds.has(d.id)) {
        const old = prev.drivers.find(p => p.id === d.id);
        if (!old) continue;
        if (
          d.name !== old.name ||
          d.transportadora !== old.transportadora ||
          d.capacidade !== old.capacidade ||
          d.tipo !== old.tipo ||
          d.viagens[0] !== old.viagens[0] ||
          d.viagens[1] !== old.viagens[1] ||
          d.viagens[2] !== old.viagens[2]
        ) {
          await supabase.from('drivers').update({
            name: d.name,
            transportadora: d.transportadora,
            capacidade: d.capacidade,
            tipo: d.tipo,
            viagem1: d.viagens[0],
            viagem2: d.viagens[1],
            viagem3: d.viagens[2],
          }).eq('id', d.id);
        }
      }
    }
  }, []);

  const addRegion = useCallback(async () => {
    const sortOrder = regions.length;
    const { data, error } = await supabase
      .from('regions')
      .insert({ name: 'Nova Região', fardos_disponiveis: 0, valor_frete: 0, sort_order: sortOrder })
      .select()
      .single();

    if (error || !data) {
      toast.error('Erro ao criar região');
      return null;
    }

    const newRegion: RegionState = {
      id: data.id,
      name: data.name,
      fardosDisponiveis: data.fardos_disponiveis,
      valorFrete: Number(data.valor_frete),
      drivers: [],
      nextId: 1,
    };

    setRegions(prev => [...prev, newRegion]);
    return data.id;
  }, [regions.length]);

  const removeRegion = useCallback(async (id: string) => {
    if (regions.length <= 1) return;
    await supabase.from('regions').delete().eq('id', id);
    setRegions(prev => prev.filter(r => r.id !== id));
  }, [regions.length]);

  const renameRegion = useCallback(async (id: string, newName: string) => {
    if (!newName.trim()) return;
    setRegions(prev => prev.map(r => r.id === id ? { ...r, name: newName.trim() } : r));
    await supabase.from('regions').update({ name: newName.trim() }).eq('id', id);
  }, []);

  return {
    regions,
    loading,
    updateRegionFull,
    addRegion,
    removeRegion,
    renameRegion,
  };
};

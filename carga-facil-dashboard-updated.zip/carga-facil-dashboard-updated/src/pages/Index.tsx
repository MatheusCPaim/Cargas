import { useState, useCallback } from "react";
import RegionTab, { RegionState } from "@/components/RegionTab";
import PosicaoAnalitica from "@/components/PosicaoAnalitica";
import { Truck, Plus, X, Pencil, Loader2, BarChart3 } from "lucide-react";
import { useRegions } from "@/hooks/useRegions";

const ANALYTICS_TAB_ID = "__posicao_analitica__";

const Index = () => {
  const { regions, loading, updateRegionFull, addRegion, removeRegion, renameRegion } = useRegions();
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [editingName, setEditingName] = useState<string | null>(null);
  const [nameInput, setNameInput] = useState('');

  const activeTabResolved = activeTab && (
    activeTab === ANALYTICS_TAB_ID || regions.find(r => r.id === activeTab)
  )
    ? activeTab
    : regions[0]?.id || null;

  const handleUpdateRegion = useCallback((updated: RegionState) => {
    const prev = regions.find(r => r.id === updated.id);
    if (prev) {
      updateRegionFull(updated, prev);
    }
  }, [regions, updateRegionFull]);

  const handleAddRegion = async () => {
    const newId = await addRegion();
    if (newId) setActiveTab(newId);
  };

  const handleRemoveRegion = async (id: string) => {
    await removeRegion(id);
    if (activeTabResolved === id) {
      const remaining = regions.find(r => r.id !== id);
      if (remaining) setActiveTab(remaining.id);
      else setActiveTab(ANALYTICS_TAB_ID);
    }
  };

  const handleStartRename = (id: string, currentName: string) => {
    setEditingName(id);
    setNameInput(currentName);
  };

  const handleFinishRename = (id: string) => {
    renameRegion(id, nameInput);
    setEditingName(null);
  };

  const activeRegion = regions.find(r => r.id === activeTabResolved);
  const isAnalytics = activeTabResolved === ANALYTICS_TAB_ID;

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex items-center gap-3 text-muted-foreground">
          <Loader2 className="animate-spin" size={24} />
          <span>Carregando dados...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center gap-3">
          <div className="p-2 rounded-xl bg-primary text-primary-foreground">
            <Truck size={22} />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight">Controle de Carregamento</h1>
            <p className="text-xs text-muted-foreground">Sistema de Gestão de Cargas</p>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="border-b border-border bg-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center gap-1 overflow-x-auto">

          {/* Posição Analítica — always first */}
          <div
            className={`group relative flex items-center gap-1.5 px-4 py-3 text-sm font-medium cursor-pointer border-b-2 transition-colors ${
              isAnalytics
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
            }`}
            onClick={() => setActiveTab(ANALYTICS_TAB_ID)}
          >
            <BarChart3 size={14} />
            <span>Posição Analítica</span>
          </div>

          {/* Divider */}
          <div className="w-px h-6 bg-border mx-1 self-center" />

          {/* Region tabs */}
          {regions.map(r => (
            <div
              key={r.id}
              className={`group relative flex items-center gap-1.5 px-4 py-3 text-sm font-medium cursor-pointer border-b-2 transition-colors ${
                activeTabResolved === r.id
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
              }`}
              onClick={() => setActiveTab(r.id)}
            >
              {editingName === r.id ? (
                <input
                  autoFocus
                  value={nameInput}
                  onChange={e => setNameInput(e.target.value)}
                  onBlur={() => handleFinishRename(r.id)}
                  onKeyDown={e => e.key === 'Enter' && handleFinishRename(r.id)}
                  onClick={e => e.stopPropagation()}
                  className="bg-transparent border-b border-primary text-sm font-medium focus:outline-none w-28"
                />
              ) : (
                <span onDoubleClick={() => handleStartRename(r.id, r.name)}>{r.name}</span>
              )}
              <button
                onClick={e => { e.stopPropagation(); handleStartRename(r.id, r.name); }}
                className="opacity-0 group-hover:opacity-60 hover:!opacity-100 transition-opacity"
              >
                <Pencil size={12} />
              </button>
              {regions.length > 1 && (
                <button
                  onClick={e => { e.stopPropagation(); handleRemoveRegion(r.id); }}
                  className="opacity-0 group-hover:opacity-60 hover:!opacity-100 transition-opacity text-destructive"
                >
                  <X size={14} />
                </button>
              )}
            </div>
          ))}

          <button
            onClick={handleAddRegion}
            className="flex items-center gap-1 px-3 py-3 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            <Plus size={14} />
            Nova Região
          </button>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {isAnalytics && (
          <PosicaoAnalitica regions={regions} />
        )}
        {!isAnalytics && activeRegion && (
          <RegionTab
            key={activeRegion.id}
            region={activeRegion}
            onUpdate={handleUpdateRegion}
          />
        )}
      </main>
    </div>
  );
};

export default Index;
